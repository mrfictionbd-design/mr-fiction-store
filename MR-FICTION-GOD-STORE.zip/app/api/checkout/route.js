import {stripe} from "../../../lib/stripe"

export async function POST(){

const session=await stripe.checkout.sessions.create({

payment_method_types:["card"],

line_items:[{
price_data:{
currency:"bdt",
product_data:{name:"MR FICTION Item"},
unit_amount:2000
},
quantity:1
}],

mode:"payment",

success_url:"http://localhost:3000",
cancel_url:"http://localhost:3000"

})

return Response.json({url:session.url})

}