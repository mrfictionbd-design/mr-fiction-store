import Navbar from "../components/Navbar"
import Hero from "../components/Hero"
import ProductGrid from "../components/ProductGrid"
import DropCountdown from "../components/DropCountdown"

export default function Home(){

return(

<div>

<Navbar/>
<Hero/>
<DropCountdown/>
<ProductGrid/>

</div>

)

}