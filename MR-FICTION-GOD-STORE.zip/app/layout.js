import './globals.css'

export const metadata={
title:"MR FICTION",
description:"We Believe In Quality"
}

export default function RootLayout({children}){
return(
<html>
<body>{children}</body>
</html>
)
}