MR FICTION GOD LEVEL STORE

SETUP

1 Install Node.js

2 Install dependencies
npm install

3 Run development server
npm run dev

4 Open browser
http://localhost:3000

FEATURES

Luxury dark streetwear UI
Animated hero section
Product grid
Drop countdown
Cart UI starter
Admin folder
Stripe checkout
Prisma database schema

DEPLOY

Push to GitHub
Deploy using Vercel

BRAND

MR. FICTION
We Believe In Quality