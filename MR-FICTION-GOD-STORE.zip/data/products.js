export const products=[

{
id:"1",
name:"MR FICTION Oversized Tee",
price:1200,
image:"/products/shirt1.jpg"
},

{
id:"2",
name:"MR FICTION Premium Hoodie",
price:2500,
image:"/products/hoodie1.jpg"
},

{
id:"3",
name:"MR FICTION Street Cap",
price:900,
image:"/products/cap1.jpg"
},

{
id:"4",
name:"MR FICTION Tote Bag",
price:700,
image:"/products/tote1.jpg"
}

]