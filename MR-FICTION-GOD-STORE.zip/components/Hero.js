import {motion} from "framer-motion"

export default function Hero(){

return(

<section className="relative h-screen flex items-center justify-center">

<video autoPlay muted loop className="absolute w-full h-full object-cover">
<source src="/video/hero.mp4" type="video/mp4"/>
</video>

<motion.div
initial={{opacity:0,y:40}}
animate={{opacity:1,y:0}}
transition={{duration:1}}
className="relative text-center">

<h1 className="text-7xl font-bold tracking-widest">
MR. FICTION
</h1>

<p className="gold mt-4 text-lg">
We Believe In Quality
</p>

<a
href="/shop"
className="mt-8 inline-block bg-gold text-black px-8 py-3">

Shop The Drop

</a>

</motion.div>

</section>

)

}