import Link from "next/link"

export default function Navbar(){

return(

<nav className="flex justify-between items-center p-6 border-b border-neutral-800">

<h1 className="text-2xl font-bold gold">
MR. FICTION
</h1>

<div className="flex gap-6">

<Link href="/">Home</Link>
<Link href="/shop">Shop</Link>
<Link href="/drops">Drops</Link>
<Link href="/cart">Cart</Link>
<Link href="/admin">Admin</Link>

</div>

</nav>

)

}