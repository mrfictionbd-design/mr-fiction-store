"use client"
import {useState,useEffect} from "react"

export default function DropCountdown(){

const target=new Date("2026-01-01")

const[time,setTime]=useState(0)

useEffect(()=>{

setInterval(()=>{
setTime(target.getTime()-Date.now())
},1000)

},[])

const days=Math.floor(time/(1000*60*60*24))

return(

<div className="text-center py-20">

<h2 className="text-4xl">
Next Drop
</h2>

<p className="gold text-3xl mt-4">
{days} Days
</p>

</div>

)

}