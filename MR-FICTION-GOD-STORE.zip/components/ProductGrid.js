import {products} from "../data/products"
import ProductCard from "./ProductCard"

export default function ProductGrid(){

return(

<section className="p-12">

<h2 className="text-3xl mb-8">
Featured Collection
</h2>

<div className="grid grid-cols-3 gap-8">

{products.map(p=>(
<ProductCard key={p.id} product={p}/>
))}

</div>

</section>

)

}