export default function ProductCard({product}){

return(

<div className="bg-accent p-4 hover:scale-105 transition duration-300">

<img src={product.image} className="w-full"/>

<h2 className="mt-4">{product.name}</h2>

<p className="gold">৳{product.price}</p>

<button className="mt-3 border px-4 py-2">
Add To Cart
</button>

</div>

)

}